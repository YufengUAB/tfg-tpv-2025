create database if not exists tpv;
use tpv;

create table if not exists usuario (
  id_usuario int auto_increment primary key,
  nombre_usuario varchar(30) not null unique,
  password varchar(30) not null,
  rol varchar(30) not null,
  fecha_creacion date not null
);

create table if not exists mesa (
  id_mesa int auto_increment primary key,
  numero varchar(30) not null,
  estado int not null
);

create table if not exists categoria (
  id_categoria int auto_increment primary key,
  nombre varchar(30) not null
);

create table if not exists producto (
  id_producto int auto_increment primary key,
  nombre varchar(30) not null,
  precio float not null,
  categoria int not null,
  cantidad_stock int not null
);

create table if not exists pedido (
  id_pedido int auto_increment primary key,
  id_usuario int not null,
  id_mesa int not null,
  precio_total float,
  total_pagado float,
  fecha_pedido date not null
);

create table if not exists detalle_pedido (
  id_detalle_pedido int auto_increment primary key,
  id_pedido int not null,
  id_producto int not null,
  cantidad int not null,
  precio_unitario float not null,
  pagados int not null
);

create table if not exists transaccion (
  id_transaccion int auto_increment primary key,
  id_pedido int not null,
  metodo_pago int not null,
  fecha_transaccion datetime not null,
  total_pagado float not null
);

insert ignore into usuario (nombre_usuario, password, rol, fecha_creacion) values ('root', 'root', 'rootUser', sysdate());
