Para crear el contendor hay que estar en el mismo directorio que el docker-compose.yml y en un terminal con Docker instalado ejecutar el siguiente comando.
- docker compose run -d --build
A veces el contenedor del backend no se enciende bien y hay que volver a la levantarlo.
- docker start spring-boot-api